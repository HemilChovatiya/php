 <div class="navbar-default sidebar" role="navigation">
 <div class="sidebar-nav navbar-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="advertiserprofile.php"><i class="fa fa-fw fa-dashboard"></i> View/Edit Profile</a>
                    </li>
                    <li>
                        <a href="adupload.php"><i class="fa fa-fw fa-bar-chart-o"></i> Upload New Advertisement</a>
                    </li>
                    <li>
                        <a href="viewuploadedads.php"><i class="fa fa-fw fa-table"></i>View Uploaded Ads And Pay</a>
                    </li>
                    <li>
                        <a href="payment.php"><i class="fa fa-fw fa-edit"></i>Payment Details</a>
                    </li>
                     <li>
                        <a href="advertiserpanel.php"><i class="fa fa-fw fa-edit"></i>Goto  Advertiser Panel</a>
                    </li>
                
                
                </ul>
            </div>
            </div>
