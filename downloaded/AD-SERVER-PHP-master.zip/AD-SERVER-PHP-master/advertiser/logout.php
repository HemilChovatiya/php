<?php
session_start();
unset($_SESSION['email']);


?>
<!DOCTYPE html>
<html>
<head>
	<title>Logout</title>
	<script>window.location.href='../index.php'</script>
	
</head>
<body>

</body>
</html>