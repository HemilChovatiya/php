 <div class="navbar-default sidebar" role="navigation">
 <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
                    <li>
                        <a href="adminpanel.php"><i class="fa fa-dashboard fa-fw nav_icon"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="adminviewadvertiser.php"><i class="fa fa-table nav_icon"></i>View/Delete Registered Advertisers</a>
                    </li>
                    <li>
                        <a href="adminviewclient.php"><i class="fa fa-table nav_icon"></i>View/Delete Registered Clients</a>
                    </li>
                      <li>
                        <a href="viewadsadmin.php"><i class="fa fa-table nav_icon"></i>View/Delete Uploaded Ads</a>
                    </li>
                    <li>
                        <a href="viewadvertiserpayment.php"><i class="fa fa-table nav_icon"></i>View Advertiser Payment Details</a>
                    </li>
                     <li>
                        <a href="viewclientpayment.php"><i class="fa fa-table nav_icon"></i>View Client Payment Details</a>
                    </li>
                 
                
                </ul>
            </div>
            </div>
