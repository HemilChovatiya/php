 <div class="navbar-default sidebar" role="navigation">
 <div class="sidebar-nav navbar-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="clientprofile.php"><i class="fa fa-fw fa-dashboard"></i> View/Edit Profile</a>
                    </li>
                    <li>
                        <a href="clientadview.php"><i class="fa fa-fw fa-bar-chart-o"></i> Select Ads/Generate HTML</a>
                    </li>
                    <li>
                        <a href="clientaccountdetails.php"><i class="fa fa-fw fa-table"></i>Add Bank Account Details</a>
                    </li>
                    <li>
                        <a href="clientpayment.php"><i class="fa fa-fw fa-edit"></i>Payment Information</a>
                    </li>
                    <li>
                        <a href="clientpanel.php"><i class="fa fa-fw fa-desktop"></i>Home</a>
                    </li>
                
                </ul>
            </div>
            </div>
