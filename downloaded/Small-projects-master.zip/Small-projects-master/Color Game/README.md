Created using HTML5, CSS3, and Vanilla Javascript.
Used Document Object Model (DOM) to create interactive web game.
