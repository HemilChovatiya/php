import React from 'react';
import ReactDOM from 'react-dom';

const Hello = () =>  <div>HAHAHAHAH</div>;

ReactDOM.render(<Hello />, document.getElementById('app'));