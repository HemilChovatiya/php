<?php $_config_vars = array (
  'sections' => 
  array (
  ),
  'vars' => 
  array (
    'page_title_homepage' => 'MRS | Homepage',
    'recommendations' => 'Recommendations based on movies you visited',
    'search' => 'Search',
    'page_title' => 'Movie Recommendation System',
    'search_placeholder' => 'Search by movie title',
    'separator' => '|',
    'no_movie_info_in_db' => 'Detailed informations about this movie are unavailable.',
    'search_on_google' => 'Ask google :)',
    'open_anyway' => 'Open Anyway',
    'more' => 'More...',
    'name' => 'name',
    'movie_you_liked' => 'Movies you liked',
    'previous_page' => 'Previous Page',
    'next_page' => 'Next Page',
    'page' => 'Page',
  ),
); ?>