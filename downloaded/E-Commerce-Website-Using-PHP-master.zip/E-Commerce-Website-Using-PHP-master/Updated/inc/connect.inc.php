<?php 
	mysql_connect("localhost","root","") or die("Couldn't connect to SQL server");
	mysql_select_db("grocerydb") or die("Couldn'ttt select DB");
?>