# StreamUP JavaScript XMPP Client

StreamUP is the official messaging App of Guru Nanak Dev Engineering College. It has been envisioned, designed and implemented exclusively for Genconians. The App is the one stop solution for all communication needs for the students and faculty members inside and out of the college campus. It is a full-fledged messaging App offering a complete, rich and innovative feature set. Users can use StreamUP to instantly find your fellow mates: juniors, seniors and all of the faculty. Users don't have to suffer through any enraging registration. Log in using your college ID and password and explore the college centric social network. Here are some of the App's most lavishing features:
 Chat using multiple accounts from a single copy of the App.
 Encrypt your messages over the medium.
 Automatic conversation back up on the server, sparing your precious phone storage.
 Pre-configured classification into groups for conference chats.
 Share files and documents of any type.
 Save your contacts on your phone and / or with your account and port them to any phone via
login.

# Project Report and Screenshots
[Screenshots](https://github.com/gursimran81/StreamUp-XMPP-Chat-App/blob/master/PROJECT%20REPORT%20FInal.pdf)
