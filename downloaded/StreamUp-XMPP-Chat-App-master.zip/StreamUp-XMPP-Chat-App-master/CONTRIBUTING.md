You find all information in our [contributor guide](https://github.com/jsxc/jsxc/wiki/Contributor-Guide).
