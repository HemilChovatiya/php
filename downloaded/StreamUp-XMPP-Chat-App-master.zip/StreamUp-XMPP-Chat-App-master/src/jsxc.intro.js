var jsxc = null, RTC = null, RTCPeerconnection = null;

(function($) {
   "use strict";
