# Automated-Time-Table

Instructions:

1. Install XAMPP server on your system to be used as local server for project.
      (lets say you installed it in 'K:\xampp_folder' folder)
2. Now copy and paste our whole project folder inside 'K:\xampp_folder\htdocs\'.
3. Start your XAMPP Control Panel and start 'Apache' and 'MySql' servers there.
4. Open your browser and type 'localhost/' or '127.0.0.1/' , then from there go to phpmyadmin.
5. Create a database named:'scheduling'  in phpmyadmin.
6. Import the sql file which is in the sql directory.
7. Congratulations.. now,you are good to go.

Thank you ... ^_^
