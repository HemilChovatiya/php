# product rating system

This is a system which rates a product using the customer reviews and comments posted on any social media site. 
For now it just only focusing on twitter feeds. User can use this system to track specific product of yours or
search for available product to see the ratings for the particular product.

## How this works

First we have to run the data mining module to collect the data for the given products which stored in the Database
and rate them using Natural Language Processing. Then store those data in to the Database.

Now user can search for a particular product name using the client application and get the rating as:

1. How many percentage of customer comments or review collected are <b>Negative</b>
2. How many percentage of customer comments or review collected are <b>Neutral</b>
3. How many percentage of customer comments or review collected are <b>Positive</b>

<i>More details will be available sooner......</i>
