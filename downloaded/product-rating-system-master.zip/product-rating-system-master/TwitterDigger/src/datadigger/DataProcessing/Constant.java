/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datadigger.DataProcessing;

/**
 *
 * @author Nipuna
 */
public class Constant {
    public static final String NOUN = "NN";    
    public static final String PLURALNOUN = "NNS";
    public static final String PROPERSINGULARNOUN = "NNP";
    public static final String PROPERPLURALNOUN = "NNPS";
    public static final String ADVERB = "RB";
    public static final String ADJECTIVE = "JJ";
    public static final String COMPARETIVEADVERB = "RBR";
    public static final String NEGATIVE = "NE";
    public static final String POSITIVE = "PO";
    public static final String NEUTRAL = "NU";
}
