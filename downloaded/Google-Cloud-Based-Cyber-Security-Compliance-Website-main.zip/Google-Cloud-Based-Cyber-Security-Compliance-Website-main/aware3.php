<html>

<head>

<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

            </head>    

 <body>

    <div>


    <nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">

        <div class="navbar-header">
        <a class="navbar-brand" href="#">
            <span style="color:Red">C</span>
            <span style="color:yellow">y</span>
            <span style="color:green">b</span>
            <span style="color:red">e</span>
            <span style="color:white">r</span> 
            <span style="color:blue">Cognizant</span></a>
        </div>
        

        <ul class="nav navbar-nav">
        <li ><a href="index.php">Home</a></li>
        <li ><a href="culture.php">Solutions</a></li>
        <!-- <li class="active"><a href="aware3.php">Resources</a></li> -->
        <li><a href="https://www.aaravrajsingh.com/">Others</a></li>
        </ul>
    </div>
    </nav>
    </div>

</body>
</html>