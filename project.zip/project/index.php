<?php
  include('function_inc.php');
  redirect('/project/pro/index.php');
?>